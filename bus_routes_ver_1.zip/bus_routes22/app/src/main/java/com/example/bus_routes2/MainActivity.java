package com.example.bus_routes2;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView fromEditText, toEditText;
    private Button dateButton, searchButton, closeCalendarButton;
    private CalendarView calendarView;
    private ImageButton menuButton, profileButton;
    private RelativeLayout calendarContainer;
    private long selectedDate = -1;
    private SimpleDateFormat dateFormatter;

    private final String[] CITIES = {"Москва", "Сочи", "Саратов"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setupAdapters();
        setupListeners();
        setDefaultDate();
    }

    private void initViews() {
        fromEditText = findViewById(R.id.fromEditText);
        toEditText = findViewById(R.id.toEditText);
        dateButton = findViewById(R.id.dateButton);
        searchButton = findViewById(R.id.searchButton);
        calendarView = findViewById(R.id.calendarView);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        calendarContainer = findViewById(R.id.calendarContainer);
        closeCalendarButton = findViewById(R.id.closeCalendarButton);
        dateFormatter = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        calendarView.setMinDate(calendar.getTimeInMillis());
        calendar.add(Calendar.YEAR, 1);
        calendarView.setMaxDate(calendar.getTimeInMillis());
    }

    private void setDefaultDate() {
        Calendar calendar = Calendar.getInstance();
        selectedDate = calendar.getTimeInMillis();
        String formattedDate = dateFormatter.format(calendar.getTime());
        dateButton.setText(formattedDate);
        calendarView.setDate(selectedDate);
    }

    private void setupAdapters() {
        ArrayAdapter<String> fromAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, CITIES);
        ArrayAdapter<String> toAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, CITIES);
        fromEditText.setAdapter(fromAdapter);
        toEditText.setAdapter(toAdapter);
        fromEditText.setThreshold(1);
        toEditText.setThreshold(1);
    }

    private void setupListeners() {
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Calendar selectedCalendar = Calendar.getInstance();
                selectedCalendar.set(year, month, dayOfMonth);
                selectedDate = selectedCalendar.getTimeInMillis();
                String formattedDate = dateFormatter.format(selectedCalendar.getTime());
                dateButton.setText(formattedDate);
                calendarContainer.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Выбрана дата: " + formattedDate, Toast.LENGTH_SHORT).show();
            }
        });
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (calendarContainer.getVisibility() == View.VISIBLE) {
                    calendarContainer.setVisibility(View.GONE);
                } else {
                    calendarContainer.setVisibility(View.VISIBLE);
                    if (selectedDate != -1) {
                        calendarView.setDate(selectedDate);
                    }
                }
            }
        });
        closeCalendarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarContainer.setVisibility(View.GONE);
            }
        });
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchTickets();
            }
        });
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProfile();
            }
        });
        fromEditText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = (String) parent.getItemAtPosition(position);
                if (toEditText.getText().toString().isEmpty()) {
                    updateToAdapter(selectedCity);
                }
            }
        });

        toEditText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = (String) parent.getItemAtPosition(position);
                if (fromEditText.getText().toString().isEmpty()) {
                    updateFromAdapter(selectedCity);
                }
            }
        });
        findViewById(R.id.mainContainer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarContainer.setVisibility(View.GONE);
            }
        });
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendarContainer.setVisibility(View.GONE);
                searchTickets();
            }
        });
    }

    private void updateToAdapter(String excludedCity) {
        List<String> filteredCities = new ArrayList<>();
        for (String city : CITIES) {
            if (!city.equals(excludedCity)) {
                filteredCities.add(city);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                filteredCities.toArray(new String[0]));
        toEditText.setAdapter(adapter);
    }

    private void updateFromAdapter(String excludedCity) {
        List<String> filteredCities = new ArrayList<>();
        for (String city : CITIES) {
            if (!city.equals(excludedCity)) {
                filteredCities.add(city);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line,
                filteredCities.toArray(new String[0]));
        fromEditText.setAdapter(adapter);
    }

    private void searchTickets() {
        String fromCity = fromEditText.getText().toString().trim();
        String toCity = toEditText.getText().toString().trim();
        if (fromCity.isEmpty() || toCity.isEmpty()) {
            Toast.makeText(this, "Заполните города отправления и назначения", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDate == -1) {
            Toast.makeText(this, "Выберите дату поездки", Toast.LENGTH_SHORT).show();
            return;
        }

        if (fromCity.equals(toCity)) {
            Toast.makeText(this, "Города отправления и назначения не могут совпадать", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Arrays.asList(CITIES).contains(fromCity) || !Arrays.asList(CITIES).contains(toCity)) {
            Toast.makeText(this, "Выберите город из списка доступных", Toast.LENGTH_SHORT).show();
            return;
        }

        List<BusTrip> availableTrips = findAvailableTrips(fromCity, toCity, selectedDate);

        if (availableTrips.isEmpty()) {
            Toast.makeText(this, "На выбранную дату рейсов нет", Toast.LENGTH_SHORT).show();
        } else {
            showSearchResults(availableTrips);
        }
    }

    private List<BusTrip> findAvailableTrips(String fromCity, String toCity, long date) {
        List<BusTrip> trips = new ArrayList<>();
        String[] departureTimes = {"08:00", "20:00"};
        int travelTime = calculateTravelTime(fromCity, toCity);
        int price = calculatePrice(fromCity, toCity);
        for (String time : departureTimes) {
            BusTrip trip = new BusTrip(fromCity, toCity, date, time, travelTime, price);
            trips.add(trip);
        }
        return trips;
    }

    private int calculateTravelTime(String fromCity, String toCity) {
        if (("Москва".equals(fromCity) && "Сочи".equals(toCity)) ||
                ("Сочи".equals(fromCity) && "Москва".equals(toCity))) {
            return 24;
        } else if (("Москва".equals(fromCity) && "Саратов".equals(toCity)) ||
                ("Саратов".equals(fromCity) && "Москва".equals(toCity))) {
            return 16;
        } else if (("Сочи".equals(fromCity) && "Саратов".equals(toCity)) ||
                ("Саратов".equals(fromCity) && "Сочи".equals(toCity))) {
            return 20;
        }
        return 12;
    }

    private int calculatePrice(String fromCity, String toCity) {
        if (("Москва".equals(fromCity) && "Сочи".equals(toCity)) ||
                ("Сочи".equals(fromCity) && "Москва".equals(toCity))) {
            return 2500;
        } else if (("Москва".equals(fromCity) && "Саратов".equals(toCity)) ||
                ("Саратов".equals(fromCity) && "Москва".equals(toCity))) {
            return 1500;
        } else if (("Сочи".equals(fromCity) && "Саратов".equals(toCity)) ||
                ("Саратов".equals(fromCity) && "Сочи".equals(toCity))) {
            return 2000;
        }
        return 1000;
    }

    private void showSearchResults(List<BusTrip> trips) {
        StringBuilder message = new StringBuilder();
        message.append("Найдено рейсов: ").append(trips.size()).append("\n\n");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        for (int i = 0; i < trips.size(); i++) {
            BusTrip trip = trips.get(i);
            message.append("Рейс ").append(i + 1).append(":\n")
                    .append(trip.getFromCity()).append(" → ").append(trip.getToCity()).append("\n")
                    .append("Дата: ").append(dateFormat.format(new Date(trip.getDate()))).append("\n")
                    .append("Время: ").append(trip.getDepartureTime()).append("\n")
                    .append("В пути: ").append(trip.getTravelTime()).append(" ч.\n")
                    .append("Цена: ").append(trip.getPrice()).append(" руб.\n\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("Результаты поиска")
                .setMessage(message.toString())
                .setPositiveButton("OK", null)
                .setNeutralButton("Забронировать", (dialog, which) -> {
                    showBookingDialog(trips);
                })
                .show();
    }

    private void showBookingDialog(List<BusTrip> trips) {
        String[] tripDescriptions = new String[trips.size()];
        for (int i = 0; i < trips.size(); i++) {
            BusTrip trip = trips.get(i);
            tripDescriptions[i] = trip.getDepartureTime() + " - " + trip.getPrice() + " руб.";
        }
        new AlertDialog.Builder(this)
                .setTitle("Выберите рейс для бронирования")
                .setItems(tripDescriptions, (dialog, which) -> {
                    BusTrip selectedTrip = trips.get(which);
                    bookTicket(selectedTrip);
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void bookTicket(BusTrip trip) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        String message = "Бронирование подтверждено!\n\n" +
                trip.getFromCity() + " → " + trip.getToCity() + "\n" +
                "Дата: " + dateFormat.format(new Date(trip.getDate())) + "\n" +
                "Время: " + trip.getDepartureTime() + "\n" +
                "Цена: " + trip.getPrice() + " руб.";

        new AlertDialog.Builder(this)
                .setTitle("Успешное бронирование")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void showMenu() {
        PopupMenu popupMenu = new PopupMenu(this, menuButton);
        popupMenu.getMenuInflater().inflate(R.menu.main_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_history) {
                Toast.makeText(MainActivity.this, "История поездок", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.menu_settings) {
                Toast.makeText(MainActivity.this, "Настройки", Toast.LENGTH_SHORT).show();
                return true;
            } else if (id == R.id.menu_help) {
                Toast.makeText(MainActivity.this, "Помощь", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });
        popupMenu.show();
    }

    private void showProfile() {
        Toast.makeText(this, "Профиль пользователя", Toast.LENGTH_SHORT).show();
    }

    private static class BusTrip {
        private String fromCity;
        private String toCity;
        private long date;
        private String departureTime;
        private int travelTime;
        private int price;

        public BusTrip(String fromCity, String toCity, long date, String departureTime, int travelTime, int price) {
            this.fromCity = fromCity;
            this.toCity = toCity;
            this.date = date;
            this.departureTime = departureTime;
            this.travelTime = travelTime;
            this.price = price;
        }

        public String getFromCity() {
            return fromCity;
        }

        public String getToCity() {
            return toCity;
        }

        public long getDate() {
            return date;
        }

        public String getDepartureTime() {
            return departureTime;
        }

        public int getTravelTime() {
            return travelTime;
        }

        public int getPrice() {
            return price;
        }
    }
}